<?php
/*
| Menu dashboard. Untuk menambah halaman baru, cukup tambah satu baris:
| 'kunci' => ['Label', 'path/dari/folder/utama.php']
*/
$menu = [
    'dashboard'  => ['Dashboard',  'Login-php/dashboard.php'],
    'profil'     => ['Profil',     'dashboard/profil.php'],
    'projects'   => ['Projects',   'dashboard/projects.php'],
    'skills'     => ['Skills',     'dashboard/skills.php'],
    'learning'   => ['Learning',   'dashboard/learning.php'],
    'experience' => ['Experience', 'dashboard/experience.php'],
    'education'  => ['Education',  'dashboard/education.php'],
    'video'      => ['Video',      'dashboard/video.php'],
    'gallery'    => ['Gallery',    'dashboard/gallery.php'],
];
?>
<aside class="dash-sidebar">

    <a class="dash-brand" href="<?= $basePath ?>Login-php/dashboard.php">
        🌿 Portfolio Willy
    </a>

    <nav class="dash-nav" aria-label="Menu dashboard">

        <?php foreach ($menu as $key => [$label, $path]): ?>

            <a
                href="<?= $basePath . $path ?>"
                <?php if ($activePage === $key): ?>
                    class="active" aria-current="page"
                <?php endif; ?>
            >
                <?= $label ?>
            </a>

        <?php endforeach; ?>

    </nav>

    <div class="dash-side-footer">

        <span>
            Masuk sebagai
            <strong><?= htmlspecialchars($username ?? '') ?></strong>
        </span>

        <a href="<?= $basePath ?>index.php">Lihat portfolio</a>

        <a href="<?= $basePath ?>Login-php/logout.php" class="dash-logout">
            Logout
        </a>

    </div>

</aside>
