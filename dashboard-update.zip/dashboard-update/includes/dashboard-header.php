<?php
/*
| Header dashboard (terpisah dari Header.php milik portfolio).
| Isi variabel ini SEBELUM meng-include file ini:
|   $basePath   -> "../" (halaman di Login-php/ atau dashboard/)
|   $pageTitle  -> judul halaman
|   $activePage -> kunci menu yang aktif (lihat dashboard-sidebar.php)
| $username berasal dari Login-php/cek_session.php.
*/

$basePath   = $basePath   ?? '../';
$pageTitle  = $pageTitle  ?? 'Dashboard';
$activePage = $activePage ?? '';
?>
<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= htmlspecialchars($pageTitle) ?> | Dashboard</title>

    <link rel="icon" href="<?= $basePath ?>pngegg.png" type="image/png">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?= $basePath ?>assets/css/dashboard-layout.css">

</head>

<body>

<div class="dash-layout">

    <?php require __DIR__ . '/dashboard-sidebar.php'; ?>

    <main class="dash-main">

        <div class="dash-content">
