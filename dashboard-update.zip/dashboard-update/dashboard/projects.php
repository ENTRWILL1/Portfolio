<?php

$basePath   = '../';
$pageTitle  = 'Projects';
$activePage = 'projects';

// Cek login harus paling atas, sebelum ada output HTML apa pun.
require_once __DIR__ . '/../Login-php/cek_session.php';
require_once __DIR__ . '/../includes/dashboard-header.php';

?>

<h1 class="dash-page-title">Projects</h1>

<p class="dash-lead">
    Kelola data Projects untuk portfolio.
</p>

<div class="dash-card">
    <p>Belum ada data. Form tambah dan edit akan muncul di sini setelah database terhubung.</p>
</div>

<?php require_once __DIR__ . '/../includes/dashboard-footer.php'; ?>
